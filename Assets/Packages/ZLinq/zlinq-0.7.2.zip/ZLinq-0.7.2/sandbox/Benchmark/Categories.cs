﻿using BenchmarkDotNet.Toolchains;
using BenchmarkDotNet.Toolchains.CsProj;

namespace Benchmark;

public static class Categories
{
    public const string LINQ = "LINQ";
    public const string ZLinq = "ZLinq";
}
