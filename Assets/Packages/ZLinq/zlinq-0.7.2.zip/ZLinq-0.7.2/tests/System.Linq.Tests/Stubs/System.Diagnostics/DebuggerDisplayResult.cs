namespace System.Diagnostics;

#nullable disable

internal class DebuggerDisplayResult
{
    public string Value { get; set; }
    public string Key { get; set; }
    public string Type { get; set; }
}
