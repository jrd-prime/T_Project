* UnitTests should use xUnit + Shoudly.
    * in that case, it includes `global namespace` so don't add `using Shouldly;`.
* class field naming, don't use `_` prefix.